<template>
  <div class="detail">
    <div class="title">培训协议</div>
    <div class="xuc-xuz-content">
      <div class="xuc-xuz-bmc">
        <p style="text-align:center;">
          <strong>007学车平台学员学车保障协议</strong>
        </p>
        <p style="text-indent:2em;">
          <br />
        </p>
        <p
          style="text-indent:2em;"
        >本协议适用于007学车服务项目，用户访问，浏览或提交学车意向及视为用户了解并认可本协议内容及007学车平台相关用户的最新政策</p>
        <p style="text-indent:2em;">
          <br />
        </p>
        <p
          style="text-indent:2em;"
        >007学车的网络媒体仅为展示方，提供的资讯信息等来自第三方驾校于教练，仅供用户参考。用户与驾校或者教练沟通联系前，请务必自行核实驾校于教练的真实情况。建议在签订合同或者缴费前先核实驾校营业执照，驾驶员培训资质等相关资质证明，于驾校签订正规的驾驶员培训合同,明确约定双方的权利于义务，并在缴费后保留好收费凭证等</p>
        <p style="text-indent:2em;">
          <br />
        </p>
        <p style="text-indent:2em;">
          用户与驾校或者教练产生的纠纷或者损失等，007学车平台不承担责任
        </p>

       
      </div>
    </div>
  </div>
</template>
<style lang="less" scoped>
.detail {
  text-align: left;
  .title {
    border-bottom: 1px solid #efefef;
    font-size: 24px;
    color: #333;
    font-weight: bold;
    text-align: left;
    padding: 20px 40px;
  }
  .xuc-xuz-bmc {
    padding: 10px 40px;
  }
}
</style>