<template>
  <div class="detail">
    <div class="title">报名条件</div>
    <div class="xuc-xuz-bmc">
      <p style="text-indent:2em;">
        <strong>(一)年龄条件</strong>
      </p>
      <p style="text-indent:2em;">1、申请小型汽车、小型自动挡汽车、轻便摩托车准驾车型的，在18周岁以上，70周岁以下;</p>
      <p style="text-indent:2em;">2、申请低速载货汽车、三轮汽车、普通三轮摩托车、普通二轮摩托车或者轮式自行机械车准驾车型的，在18周岁以上，60周岁以下;</p>
      <p style="text-indent:2em;">3、申请城市公交车、中型客车、大型货车、无轨电车或者有轨电车准驾车型的，在21周岁以上，50周岁以下;</p>
      <p style="text-indent:2em;">4、申请牵引车准驾车型的，在24周岁以上，50周岁以下;</p>
      <p style="text-indent:2em;">5、申请大型客车准驾车型的，在26周岁以上，50周岁以下。</p>
      <p style="text-indent:2em;">
        <br />
      </p>
      <p style="text-indent:2em;">
        <strong>(二)身体条件</strong>
      </p>
      <p
        style="text-indent:2em;"
      >1、身高：申请大型客车、牵引车、城市公交车、大型货车、无轨电车准驾车型的，身高为155厘米以上。申请中型客车准驾车型的，身高为150厘米以上;</p>
      <p
        style="text-indent:2em;"
      >2、视力：申请大型客车、牵引车、城市公交车、中型客车、大型货车、无轨电车或者有轨电车准驾车型的，两眼裸视力或者矫正视力达到对数视力表5.0以上。申请其他准驾车型的，两眼裸视力或者矫正视力达到对数视力表4.9以上;</p>
      <p style="text-indent:2em;">3、辨色力：无红绿色盲;</p>
      <p style="text-indent:2em;">4、听力：两耳分别距音叉50厘米能辨别声源方向;</p>
      <p style="text-indent:2em;">5、上肢：双手拇指健全，每只手其他手指必须有三指健全，肢体和手指运动功能正常;</p>
      <p style="text-indent:2em;">6、下肢：运动功能正常。申请驾驶手动挡汽车，下肢不等长度不得大于5厘米。申请驾驶自动挡汽车，右下肢应当健全;</p>
      <p style="text-indent:2em;">7、躯干、颈部：无运动功能障碍。</p>
      <p style="text-indent:2em;">
        <br />
      </p>
      <p style="text-indent:2em;">
        <strong>(三)以下情形不得申请</strong>
      </p>
      <p style="text-indent:2em;">1.有器质性心脏病、癫痫病、美尼尔氏症、眩晕症、癔病、震颤麻痹、精神病、痴呆以及影响肢体活动的神经系统疾病等妨碍安全驾驶疾病的;</p>
      <p style="text-indent:2em;">2.吸食、注射毒品、长期服用依赖性精神药品成瘾尚未戒除的;</p>
      <p style="text-indent:2em;">3.吊销机动车驾驶证未满两年的;</p>
      <p style="text-indent:2em;">4. 造成交通事故后逃逸被吊销机动车驾驶证的;</p>
      <p style="text-indent:2em;">5.驾驶许可依法被撤销未满三年的;</p>
      <p style="text-indent:2em;">6.法律、行政法规规定的其他情形。</p>
      <p style="text-indent:2em;">
        <br />
      </p>
      <p style="text-indent:2em;">
        <strong>(四)报名材料</strong>
      </p>
      <p style="text-indent:2em;">1、体检申请表(到驾校领取)</p>
      <p style="text-indent:2em;">2、身份证原件(有效期内)</p>
      <p style="text-indent:2em;">3、暂住证原件(身份证地址非本地)</p>
      <p style="text-indent:2em;">4、一寸白底彩照4张(报名中心可以拍)</p>
      <p style="text-indent:2em;">5、近视带上眼镜(报名中心也可以租借)</p>
      <p style="text-indent:2em;">6、考过摩托车驾照的把摩托车驾照带上</p>
      <p style="text-indent:2em;">7、报名费</p>
      <p style="text-indent:2em;">
        <br />
      </p>
      <p style="text-indent:2em;">
        <strong>(五)拥有摩托车证如何办理报名</strong>
      </p>
      <p style="text-indent:2em;">1、本地摩托车E照满一年后才能报考C证;</p>
      <p
        style="text-indent:2em;"
      >2、如您有本地摩托车E照，请在报名时带上进行合并(CE)证，如果您的摩托车E照是外地的，需要将其转入本地或直接在原地注销后方能报考C证。</p>
    </div>
  </div>
</template>
<style lang="less" scoped>
.detail {
    text-align: left;
  .title {
    border-bottom: 1px solid #efefef;
    font-size: 24px;
    color: #333;
    font-weight: bold;
    text-align: left;
    padding: 20px 40px;
  }
  .xuc-xuz-bmc{
      padding: 10px 40px;;
  }
}
</style>