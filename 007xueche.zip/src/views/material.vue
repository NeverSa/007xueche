<template>
  <div class="detail">
    <div class="title">准备材料</div>
    <div class="xuc-xuz-bmc">
      <p>
        <strong>（1）户籍证明：</strong>
      </p>
      <p>本地户口：身份证原件及复印件正反面各2张。</p>
      <p>外地户口：身份证原件、暂住证及复印件正反面各2张。</p>
      <p>现役军人：携带军官证、警官证或士兵证原件并出具团级以上证明。</p>
      <p>
        <br />
      </p>
      <p>
        <strong>（2）照片：</strong>
      </p>
      <p>一寸白底大头（头部占版面2/3）彩照4张（近视须带框架眼镜拍照）。</p>
      <p>
        <br />
      </p>
      <p>温馨提示：如有问题，可来电咨询客服！</p>
    </div>
  </div>
</template>
<style lang="less" scoped>
.detail {
  text-align: left;
  .title {
    border-bottom: 1px solid #efefef;
    font-size: 24px;
    color: #333;
    font-weight: bold;
    text-align: left;
    padding: 20px 40px;
  }
  .xuc-xuz-bmc {
    padding: 10px 40px;
  }
}
</style>