//test
//更新答案数据
export const updatAnswer = ({commit},arr) => {
    commit('updatAnswer',arr)
}
//更新用户
export const updatUser = ({commit},user) => {
    commit('updatUser',user)
}
